/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.php", "./*.php"],
  theme: {
    extend: {},
  },
  plugins: [],
}